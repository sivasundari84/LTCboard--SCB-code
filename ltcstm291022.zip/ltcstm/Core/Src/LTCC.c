/*
 * LTCC.c
 *

 */
#include "main.h"
#include "string.h"
#include "math.h"
#include "LTCC.h"
#include "stdbool.h"
#include "stm32f7xx_hal.h"



void LTCC_Calibration(void)
{
//	uint8_t global_config;
//   ltc_configure_channels(3,0xE80F3000);/*Rsense Resistor of 972 ohm*/
	const uint32_t RSENSE_INTEGER = 1000;
	const uint32_t RSENSE_DECIMAL = 0;
	const uint32_t loadValue =(0xE8 << 24)|(RSENSE_INTEGER << 10)|(RSENSE_DECIMAL & 0x03FF);
//	printf("%x\n", loadValue);
//	ltc_configure_channels(3, loadValue);
//  ltc_configure_channels(5, SENSOR_TYPE__RTD_PT_1000|RTD_RSENSE_CHANNEL__3|RTD_NUM_WIRES__2_WIRE|RTD_EXCITATION_MODE__NO_ROTATION_SHARING|RTD_EXCITATION_CURRENT__100UA|RTD_STANDARD__EUROPEAN);/*RTD - PT 1000*/

//	ltc_configure_channels(10, SENSOR_TYPE__OFF_CHIP_DIODE|DIODE_SINGLE_ENDED|DIODE_NUM_READINGS__3|DIODE_AVERAGING_ON|DIODE_CURRENT__80UA_320UA_640UA|DIODE_IDEALITY_FACTOR_LSB);

	ltc_configure_channels(8, SENSOR_TYPE__TYPE_K_THERMOCOUPLE|TC_COLD_JUNCTION_CH__NONE|TC_SINGLE_ENDED|TC_OPEN_CKT_DETECT__YES|TC_OPEN_CKT_DETECT_CURRENT__1MA);/*Thermocouple K Type-Single Ended*/
	/**Configure Channels at which the sensors are connected in LTC Board*/
//   ltc_configure_channels(5, SENSOR_TYPE__DIRECT_ADC|DIRECT_ADC_SINGLE_ENDED|DIRECT_ADC_CUSTOM__NO|DIRECT_ADC_CUSTOM_ADDRESS_LSB| DIRECT_ADC_CUSTOM_LENGTH_1_LSB);
//    global_config=ltc_transfer_byte(WRITE_TO_RAM,0X00F0,REJECTION__50_60_HZ|TEMP_UNIT__C);/**Set the Global Configuration Register*/
//    motor_ctrl_sig.calib = true;
//    motor_ctrl_sig.ready = true;
}


/*
 * @brief configures channel
 * @detail It is used in the Calibration phase of Motor state machine
 * @param channel_number Channel number at which the sensor is connected
 * @param channel_assignment_data Channel specific data
 * @return None
 */
void ltc_configure_channels(uint8_t channel_number,uint32_t channel_assignment_data)
{
	uint32_t ack;
	uint16_t start_address = ltc_get_start_address(CH_ADDRESS_BASE, channel_number);
	ack=ltc_transfer_four_bytes(WRITE_TO_RAM, start_address, channel_assignment_data);
}

/*
 * @brief Function definition to get the start address corresponding to the channel number across which sensor is connected
 *
 * @param base_address base address of the memory location
 * @param channel_number represents the nth channel where the sensor gets connected to that particular channel and (n-1)th channel where n>1
 * @return start address corresponding to that channel
 * */
uint16_t ltc_get_start_address(uint16_t base_address, uint8_t channel_number)
{
  return base_address + 4 * (channel_number-1);
}

/*
 * @brief Function definiton to transfer 4 bytes
 * @details This function is used only while the Channel Assignment Data(Memory address Data specific to the channel) is being sent
 * from the MCU to the LTC Board and also while receiving the measured temperature/voltage data from the LTC Board to the MCU
 * @param ram_read_or_write Read or Write signal is sent first from the MCU to the LTC Board
 * @param start_address Channel specific address
 * @see ltc_get_start_address()
 * @param input_data Represents the data which is sent as an input to the LTC Board from the MCU through MOSI Line
 * @see ltc_spi_transfer_block()
 * */

uint32_t ltc_transfer_four_bytes(uint8_t ram_read_or_write, uint16_t start_address, uint32_t input_data)
{
  uint8_t tx[7];
  uint8_t rx[7];
//  uint8_t data;
  uint32_t output_data;
  tx[0] = ram_read_or_write;
  tx[1] = (uint8_t)(start_address>>8);
  tx[2] = (uint8_t)(start_address);
  tx[3] = (uint8_t)(input_data >> 24);
  tx[4] = (uint8_t)(input_data >> 16);
  tx[5] = (uint8_t)(input_data >> 8);
  tx[6] = (uint8_t) input_data;
  HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);// CS is reset
    HAL_SPI_TransmitReceive(LTC_SPI,tx,rx,sizeof(tx),100);
    HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_SET);// CS is reset
//  HAL_SPI_Transmit(LTC_SPI,tx,sizeof(tx),100);
//  HAL_SPI_Receive(LTC_SPI,rx,sizeof(tx),100);




  output_data = (((uint32_t) (rx[3] << 24)) |
                ((uint32_t) rx[4] << 16) |
                ((uint32_t) rx[5] << 8)  |
                ((uint32_t) rx[6]));
   return output_data;
}

/*
 * @brief Function definition to measure the sensor output
 * @details We can measure the output in terms of Voltage, Resistance or Temperature and this function will have
 * print options to display the result in the console window and hence its output is of void kind
 * @param channel_number Channel number at which the sensor is connected
 * @attention If the sensor is connected between n and n-1 th channel the channel number to be chosen is n and not n-1
 * @param channel_output Specify the kind of output, if the output we need is Voltage or Temperature or Resistance
 * @return None
 * @attention We have to update this part of code specific to the state machine because the value need not be printed
 * and it has to be given as an input to the state machine to check if the Temperature values are well within the limits
 * */
float_t ltc_measure_channel(uint8_t channel_number, uint8_t channel_output)
{ /**\todo Update this function according to state machine*/
	uint32_t temperature;
	uint8_t fault_data;
	uint32_t a;
  ltc_convert_channel(channel_number);                         // start the conversion function
  temperature=ltc_get_result( channel_number, channel_output);  // Function to fetch the converted data
  fault_data=temperature>>24;
  ltc_print_fault_data(fault_data);
//  a=(temperature & 0x00FFFFFF)/1024.0F;
//  printf("a=%d",a);
  return (float_t)(temperature & 0x00FFFFFF)/1024.0F;
}

/*
 * @brief Function definition which performs the Initiate conversion action
 * @detail A conversion is initiated by writing a measurement command into RAM memory location 0x000 and
 * this function block takes care of this
 * @param channel_number Channel number at which the sensor is connected
 * @attention If the sensor is connected between n and n-1th channel the channel number to be chosen is n and not n-1
 * @return None
 */

void ltc_convert_channel(uint8_t channel_number)
{
  // Start conversion
  uint8_t x;
  x=ltc_transfer_byte(WRITE_TO_RAM, COMMAND_STATUS_REGISTER, CONVERSION_CONTROL_BYTE | channel_number);
 ltc_wait_for_process_to_finish();
}

/*
 * @brief Function definition for transfer of a single byte data
 * @param ram_read_or_write Read or Write Signal
 * @param start_address Address Specific to Channel
 * @param input_data The data that has to be sent via the MOSI line of the MCU to the LTC Board (i.e.) input to LTC Board
 * @note This function is used while transferring Global Configuration Parameters
 * */
uint8_t ltc_transfer_byte(uint8_t ram_read_or_write, uint16_t start_address, uint8_t input_data)
{
	uint8_t tx[4];
	uint8_t rx[4];
	uint8_t output_data;
    tx[0] = ram_read_or_write;
    tx[1] = (uint8_t)(start_address >> 8);
    tx[2] = (uint8_t)start_address;
    tx[3] = input_data;
//  tx[4]=0;
    HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);// CS is reset
  HAL_SPI_TransmitReceive(LTC_SPI,tx,rx,sizeof(tx),100);
  HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_SET);// CS is reset
//   HAL_SPI_Transmit(LTC_SPI,tx,sizeof(tx),100);
//     delay(25);
//   HAL_SPI_Receive(LTC_SPI,rx,sizeof(rx),100);
//  HAL_SPI_Transmit(LTC_SPI,&ram_read_or_write,1,100);
//  HAL_SPI_Transmit(LTC_SPI,(uint8_t*)&start_address,2,100);
//  HAL_SPI_Transmit(LTC_SPI,&input_data,1,100);
//  HAL_SPI_Receive(LTC_SPI,&rx,1,100);

//  HAL_SPI_TransmitReceive(LTC_SPI,tx,rx,sizeof(tx),100);
//  HAL_Delay(50);
//HAL_SPI_Transmit(LTC_SPI,&ram_read_or_write,1, 100);
////
//HAL_SPI_Transmit(LTC_SPI,(uint8_t*)start_address, 2, 100);
//HAL_SPI_Transmit(LTC_SPI,&input_data,1,100);

//   HAL_SPI_Receive(LTC_SPI,rx,4,100);
//  HAL_SPI_TransmitReceive(LTC_SPI, tx, rx, 4, 100);
//  rx=ltc_spi_transfer_block(4, tx, rx);
  output_data=rx[3];
  return output_data;
}


/*
 * @brief Function definition to check if the value 0x40 is being returned by the LTC Board in MOSI line of the LTC Board(MISO Line of the MCU)
 * which in turn indicates that the transfer of Initiate Conversion Command is a success
 * @return None
 * @see ltc_convert_channel()
 */
void ltc_wait_for_process_to_finish()
{
  uint8_t process_finished = 0;
  uint8_t data;
  while (process_finished == 0)
  {
    data = ltc_transfer_byte( READ_FROM_RAM, COMMAND_STATUS_REGISTER, 0x00);

    process_finished  = data & 0x40;
  }
}

//!@name LTC SPI Variables
//!@{
uint8_t ltc_masterRxData[LTC_TRANSFER_SIZE] = {0};
uint8_t ltc_masterTxData[LTC_TRANSFER_SIZE] = {0};
//dspi_master_config_t ltc_masterConfig;
//dspi_master_edma_handle_t ltc_g_dspi_edma_m_handle;
//edma_handle_t ltc_dspiEdmaMasterRxRegToRxDataHandle;
//edma_handle_t ltc_dspiEdmaMasterTxDataToIntermediaryHandle;
//edma_handle_t ltc_dspiEdmaMasterIntermediaryToTxRegHandle;
volatile bool ltc_isTransferCompleted = false;
//dspi_transfer_t ltc_masterXfer;
//edma_config_t ltc_userConfig;
uint32_t ltc_masterRxChannel = 0U;
uint32_t ltc_masterIntermediaryChannel = 1U;
uint32_t ltc_masterTxChannel = 2U;
//!@}



/*
 * @brief Function definition for SPI Transfer
 * @detail The communication is Half Duplex Mode
 * @param TRANSFER_SIZEE number of bytes getting transferred
 * @param ttxx array pointer to send TRANSFER_SIZEE of bytes from MCU to LTC Board
 * @param rrxx array point to receive TRANSFER_SIZEE of bytes from LTC Board to MCU
 * @note Had given the receive byte address also as an input because, without this the received value will
 * disappear once the code exits this function block and this will lead to dangling pointer issue
 *
 */
//uint8_t *ltc_spi_transfer_block(uint8_t TRANSFER_SIZEE, uint8_t *ttxx, uint8_t *rrxx)
//{
//	for(int ii=0;ii<TRANSFER_SIZEE;ii++)
//	{
////		ltc_masterTxData[ii]=ttxx[ii];
////		ltc_masterRxData[ii]=0U;
////		HAL_SPI_TransmitReceive(LTC_SPI, ttxx[ii], rrxx[ii],TRANSFER_SIZEE,100);
//
//	}
//
////    /* Start master transfer */
////    ltc_masterXfer.txData = ltc_masterTxData;
////    ltc_masterXfer.rxData = ltc_masterRxData;
////    ltc_masterXfer.dataSize = TRANSFER_SIZEE;
////    ltc_masterXfer.configFlags = kDSPI_MasterCtar0 | LTC_DSPI_MASTER_PCS_FOR_TRANSFER | kDSPI_MasterPcsContinuous;
////    ltc_g_dspi_edma_m_handle.state=0;
////    if (kStatus_Success != DSPI_MasterTransferEDMA(LTC_DSPI_MASTER_BASEADDR, &ltc_g_dspi_edma_m_handle, &ltc_masterXfer))
////    {
////        PRINTF("There is error when start LTC DSPI_MasterTransferEDMA \r\n ");
////    }
////    delay(25);
//
////    rrxx=ltc_masterRxData;
//
//    return rrxx;
//}


/*
 * @brief Function which creates a delay in milli second
 * @detail uses NOP - No Operation inside a for loop to create delays.
 * @note Can standardize this function using Counter to provide delays
 * @param delay_in_ms Delay value in milliseconds
 */
void delay(int delay_in_ms)
{
	int a=delay_in_ms*10000/144;
	for(int kk=0;kk<a;kk++)
	{
		__asm volatile("nop");
	}
}


uint8_t ltc_receive_byte(uint8_t ram_read_or_write, uint16_t start_address, uint8_t input_data)
{
	uint8_t tx[4];
	uint8_t rx[4];
	uint8_t output_data;
//    rx = (((uint32_t) (ram_read_or_write << 24)) |
//	                ((uint32_t)  start_address<< 8) |
//	                ((uint32_t) input_data << 8));
  rx[0] = ram_read_or_write;
  rx[1] = (uint8_t)(start_address >> 8);
  rx[2] = (uint8_t)start_address;
  rx[3] = input_data;
  for (int i=0; i<3; i++)
		  {
	  HAL_SPI_Transmit(LTC_SPI,&tx[i],1,100);
	  }
  HAL_Delay(25);
//    HAL_SPI_Transmit(LTC_SPI,&ram_read_or_write,1, 100);
//
//    HAL_SPI_Transmit(LTC_SPI,(uint8_t*)start_address, 2, 100);
//    HAL_SPI_Transmit(LTC_SPI,&input_data,1,100);

//   HAL_SPI_Receive(LTC_SPI,&rx[3],1,100);
// HAL_SPI_TransmitReceive(LTC_SPI,&rx,&tx,4,100);
//  rx=ltc_spi_transfer_block(4, tx, rx);
  output_data=rx[3];
  return output_data;
}


/*
 * @brief Function which receives the Temperature or the Voltage value measured in the MISO line of the MCU
 * @param channel_number Channel number at which the sensor is connected
 * @attention If the sensor is connected between n and n-1 th channel the channel number to be chosen is n and not n-1
 * @param channel_output Specify the kind of output, if the output we need is Voltage or Temperature or Resistance
 * */
uint32_t ltc_get_result( uint8_t channel_number, uint8_t channel_output)
{
  uint32_t raw_data;
  uint8_t fault_data;
  uint16_t start_address = ltc_get_start_address(CONVERSION_RESULT_MEMORY_BASE, channel_number);
  uint32_t raw_conversion_result;
  raw_data = ltc_transfer_four_bytes( READ_FROM_RAM, start_address, 0X00);
  return raw_data;
}

/*
 * @brief Function definition to calculate if the value needed is in terms of Voltage or Resistance instead of Temperature
 * @param channel_number Channel number at which the sensor is connected
 * @attention If the sensor is connected between n and n-1 th channel the channel number to be chosen is n and not n-1
 * @return None
 * */
void ltc_read_voltage_or_resistance_results(uint8_t channel_number)
{
  int32_t raw_data;
  float voltage_or_resistance_result;
  uint16_t start_address = ltc_get_start_address(VOUT_CH_BASE, channel_number);
  raw_data = ltc_transfer_four_bytes(READ_FROM_RAM, start_address, 0);
  voltage_or_resistance_result = (float)raw_data/1024000000.0;
  //PRINTF("  Voltage or resistance = %f",voltage_or_resistance_result);
}


void ltc_print_fault_data(uint8_t fault_byte)
{
  if (fault_byte & SENSOR_HARD_FAILURE)
      printf("  - SENSOR HARD FALURE");
  if (fault_byte & ADC_HARD_FAILURE)
	  printf("  - ADC_HARD_FAILURE");
  if (fault_byte & CJ_HARD_FAILURE)
	  printf("  - CJ_HARD_FAILURE");
  if (fault_byte & CJ_SOFT_FAILURE)
	  printf("  - CJ_SOFT_FAILURE");
  if (fault_byte & SENSOR_ABOVE)
	  printf("  - SENSOR_ABOVE");
  if (fault_byte & SENSOR_BELOW)
	  printf("  - SENSOR_BELOW");
  if (fault_byte & ADC_RANGE_ERROR)
	  printf("  - ADC_RANGE_ERROR");
  if (!(fault_byte & VALID))
	  printf("INVALID READING !!!!!!");
  if (fault_byte == 0b11111111)
	  printf("CONFIGURATION ERROR !!!!!!");
      printf("\nFAULT DATA = %d\n",fault_byte);
}




/*
 * @brief Initializes the configuration for LTCC
 * @return None
 * */

